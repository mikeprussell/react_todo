const sampleCategories = [
  {
    CategoryId: 1,
    CategoryName: "UI",
    CategoryDescription: "User Interface",
  },
  {
    CategoryId: 2,
    CategoryName: "Data",
    CategoryDescription: "Data Layer",
  },
];

export default sampleCategories;
