const sampleTodoItems = [
  {
    TodoId: 1,
    Action: "Create Solution",
    Done: false,
    CategoryId: 1,
    Category: {
      CategoryId: 1,
      CategoryName: "UI",
      CategoryDescription: "User Interface",
    },
  },
  {
    TodoId: 2,
    Action: "Add Project",
    Done: false,
    CategoryId: 1,
    Category: {
      CategoryId: 1,
      CategoryName: "UI",
      CategoryDescription: "User Interface",
    },
  },
];

export default sampleTodoItems;
