import React, { useState, useEffect } from "react";
import Logout from "../Auth/Logout";
import { useAuth } from "../../contexts/AuthContext";
import { Container, Jumbotron } from "react-bootstrap";
import sampleTodoItems from "../../Utilities/sampleTodoItems";
import axios from "axios";

import SingleTodoItem from "./SingleTodoItem";
import TodoItemCreate from "./TodoItemCreate";

export default function TodoItems() {
  const { currentUser } = useAuth();
  const [todoitems, setTodoItems] = useState(sampleTodoItems);

  const [categories, setCategories] = useState();
  const [showCreateForm, setShowCreateForm] = useState(false);

  const [effectTrigger, setEffectTrigger] = useState(false);

  const getTodoItems = () => {
    axios.get("http://localhost:62432/api/Todo").then((response) => {
      setTodoItems(response.data);
    });
  };

  const addTodoItem = (todoitem) => {
    console.log(todoitem);

    axios.post("http://localhost:62432/api/Todo", todoitem).then((response) => {

      let updatedTodoItems = todoitems;

      updatedTodoItems.push(response.data);

      setTodoItems(updatedTodoItems);

      setEffectTrigger(!effectTrigger);

      setShowCreateForm(false);
    });
  };

  const getCategories = () => {
    axios.get("http://localhost:62432/api/Categories").then((response) => {
      setCategories(response.data);
    });
  };

  useEffect(() => {
    getTodoItems();
    getCategories();
  }, [effectTrigger]);

  return (
    <section className="todoitems">
      <Jumbotron className="bg-primary m-0">
        <h1 className="text-center">Todo Items Dashboard</h1>
      </Jumbotron>
      {currentUser.email === "mikeprussell@outlook.com" && (
        <div className="text-center bg-dark p-3">
          <button
            className="btn btn-primary"
            onClick={() => setShowCreateForm(!showCreateForm)}
          >
            {!showCreateForm ? "Create New Todo Item" : "Cancel"}
          </button>
          <div className="createContainer">
            {showCreateForm && (
              <TodoItemCreate
                categories={categories}
                todoitems={todoitems}
                addTodoItem={addTodoItem}
              />
            )}
          </div>
        </div>
      )}
      <Container>
        <article className="todoitemGallery row justify-contentp-center">
          {todoitems.map((x) => (
            <SingleTodoItem key={x.TodoId} todoitem={x} />
          ))}
        </article>
      </Container>
      {currentUser && <Logout />}
    </section>
  );
}
