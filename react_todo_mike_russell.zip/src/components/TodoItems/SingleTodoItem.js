import React, { useState } from "react";

export default function SingleTodoItem(props) {
  return (
    <div className="singleTodoItem col-md-5 m-4">
      <h3>{props.todoitem.Action}</h3>

      <p>Category:  {props.todoitem.Category.CategoryName}</p>

      {/* <input
        type="checkbox"
        checked={props.todoitem.Done}
        onChange={() => props.callback(props.todoitem)}
      /> */}

      {/* <input
        type="checkbox"
        checked={this.props.todoitem.Done}
        onChange={() => this.props.callback(this.props.todoitem)}
      /> */}

    </div>
  );
}
