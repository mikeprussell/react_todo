import React from 'react'

export default function NotFound() {
    return (
        <div className="notFound">
            {/* <img src={image} alt="Resource Not Found... sorry for the inconvenience." /> */}
            <h1>Resource Not Found</h1>
        </div>
    )
}
